
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Driver = require('../models/Driver');

const router = express.Router();

// Driver Signup route
router.post('/signup', async (req, res) => {
  const { name, email, password, licenseNumber, vehicleTypes, availability, contact, city } = req.body;

  try {
    // Check if the driver already exists
    const existingDriver = await Driver.findOne({ email });

    if (existingDriver) {
      return res.status(400).json({ message: 'Email is already in use' });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new driver
    const newDriver = new Driver({
      name,
      email,
      password: hashedPassword,
      licenseNumber,
      vehicleTypes,
      availability,
      contact,
      city,
    });

    await newDriver.save();

    res.status(201).json({ message: 'Driver signed up successfully' });
  } catch (error) {
    console.error('Error signing up driver:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Driver Signin route
router.post('/signin', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Find the driver by email
    const driver = await Driver.findOne({ email });

    if (!driver) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Compare the entered password with the stored hashed password
    const passwordMatch = await bcrypt.compare(password, driver.password);

    if (!passwordMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Generate a JWT token for authentication
    const token = jwt.sign(
      { driverId: driver._id, email: driver.email },
      'your-secret-key', // Replace with your actual secret key
      { expiresIn: '1h' }
    );

    res.status(200).json({ token, driverId: driver._id, expiresIn: 3600 }); // 1 hour expiration
  } catch (error) {
    console.error('Error signing in driver:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
