//driverRoutes.js
const express = require('express');
const router = express.Router();
const Driver = require('../models/Driver'); // Assuming you have a Driver model

// Example server-side route for updating driver availability
router.patch('/driverProfile', async (req, res) => {
  try {
    const { driverId, availability } = req.body;

    // Assuming you have a Driver model with a field 'availability'
    const updatedDriver = await Driver.findByIdAndUpdate(
      driverId,
      { $set: { availability } },
      { new: true }
    );

    if (!updatedDriver) {
      return res.status(404).json({ message: 'Driver not found' });
    }

    return res.json({ driver: { availability: updatedDriver.availability } });
  } catch (error) {
    console.error('Error updating availability:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

module.exports = router;
