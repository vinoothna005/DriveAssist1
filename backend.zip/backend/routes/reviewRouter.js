// reviewRouter.js
const express = require('express');
const router = express.Router();
const Review = require('../models/Review');

// Route to get all reviews
router.get('/all', async (req, res) => {
  try {
    const reviews = await Review.find();
    res.json(reviews);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Route to submit a new review
router.post('/submit', async (req, res) => {
  const { rating, comment } = req.body;

  // Validate input
  if (!rating || !comment) {
    return res.status(400).json({ message: 'Rating and comment are required fields.' });
  }

  // Create a new review
  const newReview = new Review({
    rating,
    comment,
  });

  try {
    // Save the review
    const savedReview = await newReview.save();
    res.status(201).json(savedReview);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Additional routes can be added for updating, deleting, etc.

module.exports = router;
