// drivers.js (or your route file)
const express = require('express');
const router = express.Router();
const Driver = require('../models/Driver');

// Route to get available drivers with filtering based on query parameters
router.get('/available', async (req, res) => {
  try {
    // Extract query parameters from the request
    console.log('Received parameters:', req.query);
    const { city, vehicleType } = req.query;

    // Build a filter object based on the provided query parameters
    const filter = {};
    if (city) {
      filter.city = city;
    }
    if (vehicleType) {
      filter.vehicleType = vehicleType;
    }

    // Query the database with the filter
    const availableDrivers = await Driver.find({ ...filter, availability: 'Yes' });

    res.json(availableDrivers);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Additional routes can be added for updating, deleting, etc.

module.exports = router;
