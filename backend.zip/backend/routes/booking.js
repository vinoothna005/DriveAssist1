// const express = require('express');
// const router = express.Router();
// const Booking = require('../models/Booking'); // Adjust the path based on your project structure

// // Route to get all bookings
// router.get('/bookings', async (req, res) => {
//   try {
//     const bookings = await Booking.find();
//     res.json(bookings);
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// });

// // Route to add a new booking
// router.post('/bookings', async (req, res) => {
//   const booking = new Booking({
//     fromLocation: req.body.fromLocation,
//     toLocation: req.body.toLocation,
//     fromDate: req.body.fromDate,
//     fromTime: req.body.fromTime,
//     toDate: req.body.toDate,
//     toTime: req.body.toTime,
//     vehicleType: req.body.vehicleType,
//     kilometers: req.body.kilometers,

//   });

//   try {
//     const newBooking = await booking.save();
//     res.status(201).json(newBooking);
//   } catch (error) {
//     res.status(400).json({ message: error.message });
//   }
// });

// // Additional routes can be added for updating, deleting, etc.

// module.exports = router;
const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking'); // Adjust the path based on your project structure

// Route to get all bookings
router.get('/bookings', async (req, res) => {
  try {
    const bookings = await Booking.find();
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Route to add a new booking
router.post('/bookings', async (req, res) => {
  const booking = new Booking({
    city: req.body.city,
    vehicleType: req.body.vehicleType,
  });

  try {
    const newBooking = await booking.save();
    res.status(201).json(newBooking);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Additional routes can be added for updating, deleting, etc.

module.exports = router;
